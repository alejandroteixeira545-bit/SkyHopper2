# Sky Hopper 2 — projeto Android para Google Play

Projeto configurado como aplicativo Android usando o jogo HTML local dentro de um WebView.

## Configuração
- Nome: Sky Hopper 2
- Application ID: com.alejantv.skyhopper
- Versão: 1.0.0 (versionCode 1)
- minSdk: 23
- targetSdk / compileSdk: 36
- Sem permissões de rede, localização, câmera ou armazenamento.
- O progresso do jogo é salvo localmente no navegador/WebView.

## Como gerar o AAB
1. Instale uma versão atual do Android Studio compatível com API 36.
2. Abra esta pasta no Android Studio.
3. Instale Android SDK Platform 36 se o Android Studio solicitar.
4. Faça `Sync Project with Gradle Files`.
5. Use `Build > Generate Signed Bundle / APK`.
6. Escolha `Android App Bundle` e crie/seleciona uma chave de upload.
7. Gere o `release` e envie o `.aab` no Play Console.

O projeto usa AGP 8.13.2 e Gradle 8.13, compatíveis com API 36. O Google Play exige AAB para novos apps e, desde 31/08/2026, novos apps precisam target API 36 ou superior.

## Antes da publicação
Ainda é necessário preencher no Play Console os dados da ficha da loja, classificação etária, seção de segurança de dados e política de privacidade conforme o uso real do app. Também é necessário criar a conta de desenvolvedor e configurar a assinatura do app.
