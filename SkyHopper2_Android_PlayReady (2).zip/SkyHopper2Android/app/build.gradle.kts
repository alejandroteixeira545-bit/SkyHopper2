plugins { id("com.android.application") }

android { namespace = "com.alejantv.skyhopper"; compileSdk = 36
    defaultConfig { applicationId = "com.alejantv.skyhopper"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0.0" }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}
