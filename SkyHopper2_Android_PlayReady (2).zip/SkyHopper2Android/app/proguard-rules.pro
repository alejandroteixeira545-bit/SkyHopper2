# Sky Hopper 2 does not require custom R8 rules.
